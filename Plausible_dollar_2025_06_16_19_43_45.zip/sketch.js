let perguntas = [
  {
    questao: "O que geralmente motiva a migração do campo para a cidade?",
    opcoes: ["Mais empregos", "Ar puro", "Vida tranquila", "Espaço para plantar"],
    correta: 0
  },
  {
    questao: "Qual é uma consequência comum da migração do campo para a cidade?",
    opcoes: ["Desemprego rural", "Crescimento urbano", "Desmatamento", "Menos carros"],
    correta: 1
  },
  {
    questao: "Como a mecanização impacta o campo?",
    opcoes: ["Aumenta empregos", "Reduz necessidade de mão de obra", "Causa superlotação", "Melhora o trânsito"],
    correta: 1
  },
  {
    questao: "O que é êxodo rural?",
    opcoes: ["Saída da cidade para o campo", "Viagem de férias", "Migração do campo para a cidade", "Transporte agrícola"],
    correta: 2
  },
  {
    questao: "Quais serviços básicos costumam atrair pessoas para as cidades?",
    opcoes: ["Hospitais e escolas", "Plantio de soja", "Galpões e celeiros", "Tratores modernos"],
    correta: 0
  },
  {
    questao: "Qual problema social pode surgir com o êxodo rural?",
    opcoes: ["Falta de terras no campo", "Explosão demográfica urbana", "Excesso de escolas rurais", "Aumento da agricultura"],
    correta: 1
  },
  {
    questao: "O que pode ser feito para melhorar a vida no campo?",
    opcoes: ["Investir em tecnologia rural", "Fechar escolas", "Diminuir estradas", "Eliminar plantações"],
    correta: 0
  }
];

let perguntaAtual = 0;
let pontuacao = 0;
let mostrandoFeedback = false;
let feedback = "";
let fimDeJogo = false;

function setup() {
  createCanvas(800, 400);
  textAlign(CENTER, CENTER);
  textSize(20);
}

function draw() {
  background(240);

  if (fimDeJogo) {
    fill(0);
    text("Fim do jogo!", width / 2, height / 2 - 40);
    text("Sua pontuação: " + pontuacao + " de " + perguntas.length, width / 2, height / 2);
    return;
  }

  let pergunta = perguntas[perguntaAtual];

  fill(0);
  text("Pergunta " + (perguntaAtual + 1) + ": " + pergunta.questao, width / 2, 50);

  for (let i = 0; i < pergunta.opcoes.length; i++) {
    let y = 120 + i * 50;
    fill(200);
    rect(150, y, 500, 40, 10);
    fill(0);
    text(pergunta.opcoes[i], 400, y + 20);
  }

  if (mostrandoFeedback) {
    fill(feedback === "Correto!" ? "green" : "red");
    text(feedback, width / 2, height - 40);
  }
}

function mousePressed() {
  if (fimDeJogo || mostrandoFeedback) {
    return;
  }

  let pergunta = perguntas[perguntaAtual];

  for (let i = 0; i < pergunta.opcoes.length; i++) {
    let y = 120 + i * 50;
    if (mouseX > 150 && mouseX < 650 && mouseY > y && mouseY < y + 40) {
      if (i === pergunta.correta) {
        pontuacao++;
        feedback = "Correto!";
      } else {
        feedback = "Errado!";
      }
      mostrandoFeedback = true;
      setTimeout(() => {
        mostrandoFeedback = false;
        perguntaAtual++;
        if (perguntaAtual >= perguntas.length) {
          fimDeJogo = true;
        }
      }, 1000);
    }
  }
}